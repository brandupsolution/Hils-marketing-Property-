# Citizens Gallery Apartments – HILS Marketing & Property

Static website (HTML/CSS/JS, no build step).

## Publish on GitHub Pages
1. Create a new repository on GitHub (e.g. `citizens-gallery`).
2. Upload everything in this folder (`index.html`, `images/`, `README.md`) to the repository root.
3. Go to **Settings > Pages**, set Source to **Deploy from a branch**, choose **main** and **/ (root)**, then Save.
4. After a minute the site is live at `https://<your-username>.github.io/citizens-gallery/`.
